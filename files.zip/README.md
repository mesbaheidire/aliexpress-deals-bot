# بوت تخفيضات AliExpress (تيليجرام)

بوت تيليجرام: تبعثله أي رابط منتج من AliExpress (في الخاص، جروب، أو قناة يكون فيها أدمن)،
يرد عليك بأفضل سعر متوفر، نسبة الخصم، ورابط شراء بعمولة (Affiliate Link).

---

## 1. جهّز المفاتيح المطلوبة

### أ) توكن بوت تيليجرام
1. افتح تيليجرام وابحث عن `@BotFather`.
2. أرسل `/newbot` واتبع التعليمات.
3. ينعطيك **Token** شكله تقريباً `123456:ABC-DEF...` — احتفظ به.
4. إذا بغيت تستخدمه فـ **قناة**: زيد البوت كأدمن فالقناة.

### ب) مفاتيح AliExpress Affiliate API
1. روح لـ https://portals.aliexpress.com وسجل كـ Affiliate (مسوّق بالعمولة) إذا ماعندكش حساب.
2. من لوحة التحكم روح لقسم **API** / **Apps** وأنشئ تطبيق (App).
3. راح تحصل على:
   - `App Key`
   - `App Secret`
   - و`Tracking ID` (تقدر تنشئه من قسم Tracking ID فنفس اللوحة)

> ⚠️ من دون هاذوك المفاتيح البوت ما يقدرش يجيب أسعار ولا يولّد روابط عمولة.

---

## 2. ارفع المشروع على GitHub
```bash
cd aliexpress-deals-bot
git init
git add .
git commit -m "init"
git branch -M main
git remote add origin <رابط الريبو ديالك>
git push -u origin main
```
**تنبيه:** لا ترفع ملف `.env` الحقيقي فيه مفاتيحك — استعمل `.env.example` كمرجع فقط،
والمفاتيح الحقيقية تحطها فـ Render (خطوة جاية).

---

## 3. النشر على Render
1. https://dashboard.render.com → **New +** → **Web Service**.
2. اربطه بريبو GitHub ديالك.
3. الإعدادات:
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `python main.py`
   - **Instance Type:** Free
4. فـ **Environment** زيد المتغيرات:
   - `TELEGRAM_BOT_TOKEN`
   - `ALIEXPRESS_APP_KEY`
   - `ALIEXPRESS_APP_SECRET`
   - `ALIEXPRESS_TRACKING_ID`
5. Deploy. Render باش يعطيك رابط شكل `https://your-app.onrender.com` —
   البوت يستعمله وحدو باش يضبط الـ webhook (مافيهاش شي حاجة تديرها يدوياً).
6. راقب اللوقز (Logs)، إذا بانت رسالة `تم ضبط الـ webhook على: ...` معناها كلشي مزيان.

---

## 4. تفعيل cron-job.org (باش الخدمة المجانية ما تناعسش)
خدمة Render المجانية توقف (sleep) إذا محدش زارها لمدة معينة، وهذا يبطّئ أول رد.
باش نحلو هذا:

1. https://cron-job.org/en/ → أنشئ حساب.
2. **Create cronjob**:
   - **URL:** `https://your-app.onrender.com/`
   - **Schedule:** كل 10 دقائق (`*/10 * * * *`)
3. حفظ. هاذي الخدمة غادي تدير GET request كل 10 دقائق باش تبقى الخدمة صاحية.

---

## 5. الاستخدام
- بعث رابط منتج من AliExpress للبوت (فـ الخاص أو فـ قناة البوت فيها أدمن).
- البوت يرد بـ: صورة المنتج، السعر بعد التخفيض، السعر الأصلي، نسبة الخصم، ورابط الشراء (فيه العمولة ديالك).

يشتغل مع الروابط الطويلة (`aliexpress.com/item/12345.html`) وكذلك الروابط المختصرة
(`a.aliexpress.com/...`) — البوت يفكها أوتوماتيكياً.

---

## ملاحظات مهمة
- البوت ما "يبحثش" فـ كل الموقع على منتج أرخص مشابه — كايجيب السعر والخصم **الحقيقي** لنفس
  المنتج اللي بعثتيه (لي هو أدق وأوثق مصدر، لأن AliExpress ما كايعطيش API للمقارنة بين منتجات مختلفة).
- إذا بغيت زيادة ميزة "تنبيهات تلقائية بالعروض اليومية" (بدون ما يبعث حد رابط)، يمكن نزيدو
  Cron Job داخلي (APScheduler) يجيب أفضل عروض اليوم من `aliexpress.affiliate.hotproduct.query`
  ويبعثها للقناة تلقائياً — قوليلي إذا حاب هاذشي ونزيدو.
